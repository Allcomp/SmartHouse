<?php
$_CONFIG['ip'] = "178.17.7.4";
//$_CONFIG['ip'] = "10.0.0.177";
$_CONFIG['port'] = "81";
$_CONFIG['default_permission_level'] = 50;
$_CONFIG['require_login'] = true;
$_CONFIG['not_require_login_in_LAN'] = true;
$_CONFIG['cameras_source'] = "http://10.0.0.220";

$_CONFIG['dbhost'] = "localhost";
$_CONFIG['dbuser'] = "root";
$_CONFIG['dbpass'] = "123456";
$_CONFIG['dbname'] = "smart_control";