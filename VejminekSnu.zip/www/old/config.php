<?php
$_CONFIG['ip'] = "10.0.2.1";
$_CONFIG['port'] = "81";
$_CONFIG['default_permission_level'] = 50;
$_CONFIG['require_login'] = false;
$_CONFIG['not_require_login_in_LAN'] = false;

$_CONFIG['dbhost'] = "localhost";
$_CONFIG['dbuser'] = "root";
$_CONFIG['dbpass'] = "123456";
$_CONFIG['dbname'] = "smart_control";