<?php
$_CONFIG['ip'] = "192.168.42.1";
$_CONFIG['port'] = "81";

$_CONFIG['dbhost'] = "localhost";
$_CONFIG['dbuser'] = "smarthouse";
$_CONFIG['dbpass'] = "123456";
$_CONFIG['dbname'] = "sevid_smart_control";