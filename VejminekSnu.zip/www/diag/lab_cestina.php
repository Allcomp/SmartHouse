<?php
//HEADER
session_start();
Header("Cache-control: no-cache");
Header("Pragma: no-cache");
Header("Expires: 0");
Header("Content-Type: text/html; charset=Windows-1250");
extract($_REQUEST);
?>
