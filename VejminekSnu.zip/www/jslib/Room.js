/**
 * Created by Samuel on 13.08.2015.
 */

var Room = function(id, name, floor) {
    this.id = id;
    this.name = name;
    this.floor = floor;
};